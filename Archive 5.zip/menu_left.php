<?PHP
    if (!isset($_SESSION['sessunameetilang'])) {
        header('location:index.php');
    }
?>

<nav class="side-menu">
    <div class="side-menu-avatar">
        <div class="avatar-preview avatar-preview-100">
            <img src="img/avatar-1-256.png" alt="">
        </div>
        <center>
            <span class="lbl"><?PHP echo $_SESSION['sessnameetilang'];?></span><br>
        </center>
    </div>
    <ul class="side-menu-list">
        <li class="brown">
            <a href="home.php">
                <i class="font-icon glyphicon glyphicon-home"></i>
                <span class="lbl">Home</span>
            </a>
        </li>
        <!kalo menunya lagi open kasih atribut opened-->
        <li class="blue-dirty">
            <a href="pelanggaran_overview.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Daftar Pelanggaran</span>
            </a>
        </li>
        <li class="blue-dirty">
            <a href="pelanggaran_personil_overview.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Daftar Pelanggaran Personil</span>
            </a>
        </li>
        <li class="blue-dirty">
            <a href="blacklist_overview.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Daftar Blacklist</span>
            </a>
        </li>
        <li class="blue-dirty">
            <a href="m_penanggungjawab.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Master Penanggungjawab</span>
            </a>
        </li>
        <li class="blue-dirty">
            <a href="m_pelanggaran.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Master Pelanggaran</span>
            </a>
        </li>
        <li class="blue-dirty">
            <a href="m_lokasi.php">
                <i class="font-icon glyphicon glyphicon-th"></i>
                <span class='lbl'>Master Lokasi</span>
            </a>
        </li>
        <li class="red">
            <a href="logout.php">
                <i class="font-icon glyphicon glyphicon-log-out"></i>
                <span class="lbl">Logout</span>
            </a>
        </li>
    </ul>
</nav><!--.side-menu-->