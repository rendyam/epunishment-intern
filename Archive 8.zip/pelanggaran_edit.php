<?PHP
    session_start();

    if (!isset($_SESSION['sessunameetilang'])) {
        header('location:index.php');
    }

    include "koneksi/connect-db.php";
    include "f_setter_getter_serial.php";

    $modeDebug = 1;
    $strMessage = "";
    
    $select_klasifikasi = "";
    
    try {
        $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
        
        $query = "select * from gen_klasifikasi_tab";
        
        $result = $db->prepare($query);
        $result->execute();

        $num = $result->rowCount();

        if($num > 0) {
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $select_klasifikasi = $select_klasifikasi."<option value='$row[0]'>$row[1]</option>";
            }
        }
        $db = null;
    } catch (Exception $e) {
        if($modeDebug==0){
            $select_klasifikasi = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
        }else{
            $select_klasifikasi = $e->getMessage();
        }
    }

    $nama_pelanggar_select = "";
    
    try {
        $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
        
        $query = "select * from gen_pelanggar_tab";
        
        $result = $db->prepare($query);
        $result->execute();

        $num = $result->rowCount();

        if($num > 0) {
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $nama_pelanggar_select = $nama_pelanggar_select."<option value='$row[0]' data-noktp='$row[2]'>$row[1]</option>";
            }
        }
        
        $db = null;
    } catch (Exception $e) {
        if($modeDebug==0){
            $strMessage = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
        }else{
            $strMessage = $e->getMessage();
        }
    }

    $perusahaan_pj_select = "";
    
    try {
        $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
        
        $query = "select * from gen_penanggungjawab_tab where status_pj = 1";
        
        $result = $db->prepare($query);
        $result->execute();

        $num = $result->rowCount();

        if($num > 0) {
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $perusahaan_pj_select = $perusahaan_pj_select."<option value='$row[0]'>$row[1]</option>";
            }
        }
        
        $db = null;
    } catch (Exception $e) {
        if($modeDebug==0){
            $strMessage = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
        }else{
            $strMessage = $e->getMessage();
        }
    }

    $lokasi_select = "";
    
    try {
        $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
        
        $query = "select * from gen_lokasi_tab where status_lokasi = 1";
        
        $result = $db->prepare($query);
        $result->execute();

        $num = $result->rowCount();

        if($num > 0) {
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $lokasi_select = $lokasi_select."<option value='$row[0]'>$row[1]</option>";
            }
        }
        
        $db = null;
    } catch (Exception $e) {
        if($modeDebug==0){
            $strMessage = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
        }else{
            $strMessage = $e->getMessage();
        }
    }

    $jenis_pelanggaran_select = "";
    
    try {
        $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
        
        $query = "SELECT a.id_pelanggaran, b.jenis, a.pelanggaran FROM gen_pelanggaran_tab a LEFT JOIN gen_jenis_pelanggaran_tab b ON a.id_jenis=b.id_jenis WHERE a.status_pelanggaran = 1";
        
        $result = $db->prepare($query);
        $result->execute();

        $num = $result->rowCount();

        if($num > 0) {
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $jenis_pelanggaran_select = $jenis_pelanggaran_select."<option value='$row[0]'>$row[1] - $row[2]</option>";
            }
        }
        
        $db = null;
    } catch (Exception $e) {
        if($modeDebug==0){
            $strMessage = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
        }else{
            $strMessage = $e->getMessage();
        }
    }

    if (isset($_POST['simpan_pelanggaran']) and $_SERVER['REQUEST_METHOD'] == "POST") {
        date_default_timezone_set('Asia/Jakarta');
        $date = new DateTime();
        $date = $date->getTimestamp();
        $date = date("Y-m-d H:i:s", $date);

        try {
            $db = new PDO("mysql:host=$host3306;port=$dbport3306;dbname=$dbname3306", $dbuser3306, $dbpass3306, array(PDO::MYSQL_ATTR_FOUND_ROWS => true));

            // echo json_encode($_FILES);

            $tglPelanggaran =$_POST['tanggal'];
            $tglPelanggaran = explode('/', $tglPelanggaran);
            $tglPelanggaran = $tglPelanggaran[2] . "-" . $tglPelanggaran[0] . "-" . $tglPelanggaran[1];
            $waktu = $_POST['waktu'];
            $jenisTrx = $_POST['klasifikasi_select'];
            $id_pelanggar = $_POST['nama_pelanggar_select'];
            if($_POST['klasifikasi_select'] != 3){
                $txtNopol = $_POST['nopol_select'];
            }
            $txtKTP = $_POST['no_ktp_front'];
            $pekerjaan = $_POST['pekerjaan'];
            $cmbPJ = $_POST['perusahaan_select'];
            $cmbLokasi = $_POST['lokasi_select'];
            $cmbPelanggaran = $_POST['pelanggaran_select'];
            $txtKeterangan = $_POST['keterangan'];
            $picTilang = $_SESSION["sessidetilang"];
            $status = 'Draft';
            
            $db->beginTransaction();
            
            $txtKode = getNomorBerikutnya("TLG");
            
            $sqlQuery = $db->prepare("
                                INSERT INTO 
                                    pelanggaran_tab(
                                        id_trx, 
                                        jenis_trx, 
                                        tgl_trx, 
                                        waktu, 
                                        no_polisi, 
                                        id_pj, 
                                        no_ktp, 
                                        id_pelanggaran, 
                                        id_lokasi, 
                                        keterangan, 
                                        pic_tilang, 
                                        status,
                                        pekerjaan,
                                        id_pelanggar
                                    ) 
                                VALUES
                                    (
                                        :id_trx, 
                                        :jenis_trx, 
                                        :tgl_trx, 
                                        :waktu, 
                                        :no_polisi, 
                                        :id_pj, 
                                        :no_ktp, 
                                        :id_pelanggaran, 
                                        :id_lokasi, 
                                        :keterangan, 
                                        :pic_tilang, 
                                        :status,
                                        :pekerjaan,
                                        :id_pelanggar
                                    )
                                ");

            $sqlQuery->bindParam(':id_trx', $txtKode, PDO::PARAM_STR);
            $sqlQuery->bindParam(':jenis_trx', $jenisTrx, PDO::PARAM_STR);
            $sqlQuery->bindParam(':tgl_trx', $tglPelanggaran, PDO::PARAM_STR);
            $sqlQuery->bindParam(':waktu', $waktu, PDO::PARAM_STR);
            $sqlQuery->bindParam(':no_polisi', $txtNopol, PDO::PARAM_STR);
            $sqlQuery->bindParam(':id_pj', $cmbPJ, PDO::PARAM_STR);
            $sqlQuery->bindParam(':no_ktp', $txtKTP, PDO::PARAM_STR);
            $sqlQuery->bindParam(':id_pelanggaran', $cmbPelanggaran, PDO::PARAM_STR);
            $sqlQuery->bindParam(':id_lokasi', $cmbLokasi, PDO::PARAM_STR);
            $sqlQuery->bindParam(':keterangan', $txtKeterangan, PDO::PARAM_STR);
            $sqlQuery->bindParam(':pic_tilang', $picTilang, PDO::PARAM_STR);
            $sqlQuery->bindParam(':status', $status, PDO::PARAM_STR);
            $sqlQuery->bindParam(':pekerjaan', $pekerjaan, PDO::PARAM_STR);
            $sqlQuery->bindParam(':id_pelanggar', $id_pelanggar, PDO::PARAM_STR);

            $sqlQuery->execute();

            if($sqlQuery->rowCount() > 0){
                if($_FILES['foto_tilang']['name'][0] != ""){
                    for($i = 0; $i<count($_FILES['foto_tilang']['name']); $i++){
                        $filetmp = $_FILES['foto_tilang']['tmp_name'][$i];
                        $filename = $_FILES['foto_tilang']['name'][$i];
                        $filetype = $_FILES['foto_tilang']['type'][$i];
                        $filepath = "foto_tilang/".$filename;
        
                        move_uploaded_file($filetmp, $filepath);
        
                        $sqlFotoTilang = $db->prepare("insert into pelanggaran_foto_tab (id_trx, foto_path) VALUES (:id_trx, :foto_path)");
                        
                        $sqlFotoTilang->bindParam(':id_trx', $txtKode, PDO::PARAM_STR);
                        $sqlFotoTilang->bindParam(':foto_path', $filepath, PDO::PARAM_STR);

                        $sqlFotoTilang->execute();
                    }
                }
                //function blacklist
                $queryBlacklist = "SELECT a.jumlah_sp_aktif, a.masa_berlaku from pelanggaran_rpt a WHERE a.no_polisi = '$txtNopol'";

                $result = $db->prepare($queryBlacklist);
                $result->execute();

                $num = $result->rowCount();

                if($num >= 3) {
                    $stsBlok = 1;

                    $sqlQueryBlacklist = $db->prepare("insert into blacklist_tab(no_polisi, tanggal_blok, status_blok) values(:no_polisi, :tanggal_blok, :status_blok)");

                    $sqlQueryBlacklist->bindParam(':no_polisi', $txtNopol, PDO::PARAM_STR);
                    $sqlQueryBlacklist->bindParam(':tanggal_blok', $date, PDO::PARAM_STR);
                    $sqlQueryBlacklist->bindParam(':status_blok', $stsBlok, PDO::PARAM_STR);

                    $sqlQueryBlacklist->execute();
                }

            setNomorBerikutnya("TLG");

            $db->commit();

            // echo json_encode($_POST);

            //     header('location:pelanggaran_ab_edit.php?id='.base64_encode($txtKode));

            //     //header('location:home.php');
                $strMessage = "<div class='alert alert-success'><strong>Data berhasil disimpan</strong></div>";
            } else {
                $strMessage = "<div class='alert alert-error'><strong>Data gagal disimpan</strong></div>";
                // echo json_encode($strMessage);
            }
            
        }catch(PDOException $e){
            if($modeDebug==0){
                $strMessage = "<div class='alert alert-danger alert-fill alert-close alert-dismissible fade show' role='alert'>Oops, there is something wrong.....</div>";
            }else{
                $strMessage = $e->getMessage();
            }
            // echo json_encode($strMessage);
        }
    }
?>

<!DOCTYPE html>
<html>
    <head lang="en">
        <?PHP
            include "header.php";
        ?>

        <link rel="stylesheet" href="css/lib/flatpickr/flatpickr.min.css">
        <link rel="stylesheet" href="css/separate/vendor/flatpickr.min.css">
        <link rel="stylesheet" href="css/separate/vendor/bootstrap-daterangepicker.min.css">
        <link rel="stylesheet" href="css/lib/clockpicker/bootstrap-clockpicker.min.css">
        <link rel="stylesheet" href="css/separate/vendor/bootstrap-select/bootstrap-select.min.css">
        <link rel="stylesheet" href="css/separate/pages/others.min.css">
        <link href="plugins/bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
        <style>
            .required {
                color: red;
            }
        </style>
    </head>
    <body class="with-side-menu">

        <header class="site-header">
            <div class="container-fluid">
                    
                    <!logo startui-->
                <!--<a href="#" class="site-logo">
                    <img class="hidden-md-down" src="img/logo-2.png" alt="">
                    <img class="hidden-lg-down" src="img/logo-2-mob.png" alt="">
                </a>-->
                    
                    <!toggle show hide menu-->
                <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
                    <span>toggle menu</span>
                </button>
        
                <button class="hamburger hamburger--htla">
                    <span>toggle menu</span>
                </button>
                <?PHP include "menu_up.php";?>
            </div><!--.container-fluid-->
        </header><!--.site-header-->

        <div class="mobile-menu-left-overlay"></div>

        <?PHP include "menu_left.php";?>

        <div class="page-content">
            <div class="container-fluid">
                <div class="box-typical box-typical-full-height">
                    <div class="add-customers-screen tbl">
                        <div class="add-customers-screen-in">
                            <div class="add-customers-screen-user">
                                <i class="font-icon font-icon-pencil"></i>
                            </div>
                            <h2>Halaman sedang dalam maintenance</h2>
                            <p class="lead color-blue-grey-lighter">Mohon maaf atas ketidaknyamanannya<br/>Halaman akan dapat segera diakses secepatnya.<br/>Info: rendyaulia.ptkbs@gmail.com</p>
                        </div>
                    </div>
                </div><!--.box-typical-->
            </div><!--.container-fluid-->
        </div><!--.page-content-->



        <script src="js/lib/jquery/jquery-3.2.1.min.js"></script>
        <script src="js/lib/popper/popper.min.js"></script>
        <script src="js/lib/tether/tether.min.js"></script>
        <script src="js/lib/bootstrap/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        
        <script src="js/lib/select2/select2.full.min.js"></script>
        <script type="text/javascript" src="js/lib/moment/moment-with-locales.min.js"></script>
        <script type="text/javascript" src="js/lib/flatpickr/flatpickr.min.js"></script>
        <script src="js/lib/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="js/lib/clockpicker/bootstrap-clockpicker-init.js"></script>
        <script src="js/lib/daterangepicker/daterangepicker.js"></script>
        <script src="js/lib/bootstrap-select/bootstrap-select.min.js"></script>
        <script src="plugins/bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>

        <script src="js/jquery-validation-1.19.2/dist/jquery.validate.min.js"></script>

        <script src="js/app.js"></script>

    </body>
</html>