<?php
define('EMAIL', 'kirimemail.ptkbs@gmail.com');
define('PASS', 'kirimemail@2020');
