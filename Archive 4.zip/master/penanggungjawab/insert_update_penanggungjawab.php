<?php
    include "../../koneksi/connect-db.php";

    if(isset($_POST["operation"])){
        if($_POST["operation"] == 'Tambah'){
            $namaPenanggungJawab = $_POST["nama_penanggungjawab"];

            $db->beginTransaction();
            
            $statusPenanggungJawab = 1;

            $sqlQuery = $db->prepare("
                insert into gen_penanggungjawab_tab(nama_pj, status_pj) 
                values(:nama_pj, :status_pj)
            ");

            $sqlQuery->bindParam(':nama_pj', $namaPenanggungJawab, PDO::PARAM_STR);
            $sqlQuery->bindParam(':status_pj', $statusPenanggungJawab, PDO::PARAM_STR);

            $result = $sqlQuery->execute();

            $db->commit();

            if(!empty($result)){
                echo "Berhasil ditambah!";
            }
        }
        if($_POST["operation"] == 'Edit'){
            $statement = $db->prepare("
                            UPDATE 
                                gen_penanggungjawab_tab
                            SET 
                                nama_pj = :nama_pj
                            WHERE id_pj = :id_pj
                        ");
            $statement->execute(
                array(
                    ':nama_pj' => $_POST['nama_penanggungjawab'],
                    ':id_pj' => $_POST['penanggungjawab_id']
                )
            );
            echo "Berhasil diedit!";
        }
    }
?>